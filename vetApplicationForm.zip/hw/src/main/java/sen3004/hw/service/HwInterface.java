package sen3004.hw.service;

import java.util.List;

import sen3004.hw.model.Dog;

public interface HwInterface {
	
	public List<Dog> findAll();
	
	public void create(Dog dog);
	
	public Dog findById(long id);
	
	public void update(Dog dog);
}
