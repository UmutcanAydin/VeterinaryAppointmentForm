package sen3004.hw.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sen3004.hw.dao.HwRepository;
import sen3004.hw.model.Dog;

@Service
@Transactional
public class HwService implements HwInterface {
	
	@Autowired
	HwRepository hwRepository;
	
	@Override
	public List<Dog> findAll() {
		return hwRepository.findAll(); 
	}

	@Override
	public void create(Dog dog) {
		hwRepository.create(dog);
	}

	@Override
	public Dog findById(long id) {
		return hwRepository.findById(id);
	}

	@Override
	public void update(Dog dog) {
		hwRepository.update(dog);
	}

}
