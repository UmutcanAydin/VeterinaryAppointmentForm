package sen3004.hw.validator;

import org.springframework.validation.Validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import sen3004.hw.model.Dog;

@Component
public class validator implements Validator {
	
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Dog.class.isAssignableFrom(clazz);
	}
	
	@Override
	public void validate(Object target,Errors errors) {
		Dog dog = (Dog)target;
		if(dog.getDateOfAppointment().getDayOfWeek().getValue() == 7) {
			errors.rejectValue("dateOfAppointment", "custom.error");
		}
	}
}
