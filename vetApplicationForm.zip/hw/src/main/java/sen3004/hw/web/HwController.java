package sen3004.hw.web;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import sen3004.hw.model.Dog;
import sen3004.hw.service.HwService;
import sen3004.hw.validator.validator;

@Controller
public class HwController {
	
	@Autowired
	HwService hwService;
	
	@Autowired
	validator vd;
	
	@RequestMapping(value = "/vet-form",method = RequestMethod.GET)
	public ModelAndView display() {
		ModelAndView mv = new ModelAndView("dogForm");
		mv.addObject("dog",new Dog());
		return mv;
	}
	
	@RequestMapping(value = "/send",method = RequestMethod.POST )
	public ModelAndView proccess(@Valid @ModelAttribute Dog dog,BindingResult result) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("dog",dog);
		
		if(dog.getDateOfAppointment() != null) {
			vd.validate(dog, result);
		}
		
		if(result.hasErrors())
			mv.setViewName("dogForm");
		else {
			mv.setViewName("dogResult");
			hwService.create(dog);
			mv.addObject("doglist", hwService.findAll());
		}
		return mv;
		
	}
	
	@RequestMapping(value = {"/dog-list", "list.html"}, method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView mv = new ModelAndView("dogResult");
		mv.addObject("doglist", hwService.findAll());
		
		return mv;
	}
	
	private Long id;
	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable long id) {
		ModelAndView mv = new ModelAndView("dogEdit");
		this.id = id;
		Dog temp = hwService.findById(id);
		mv.addObject("dog",temp);
		
		return mv;
	}
	
	@RequestMapping(value = "/edittedSend",method = RequestMethod.POST )
	public ModelAndView edit(@Valid @ModelAttribute Dog dog,BindingResult result) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("dog",dog);
		
		if(dog.getDateOfAppointment() != null) {
			vd.validate(dog, result);
		}
		
		if(result.hasErrors())
			mv.setViewName("dogEdit");
		else {
			mv.setViewName("dogResult");
			dog.setId(id);
			hwService.update(dog);
			mv.addObject("doglist", hwService.findAll());
		}
		return mv;
		
	}
	
		
	@ModelAttribute("breeds")
	public List<String> breeds()
	{
	    ArrayList<String> breeds = new ArrayList<String>();
	    breeds.add("Rottweiler");
	    breeds.add("Retriever");
	    breeds.add("Scottish Terrier");
	    breeds.add("German Shepherd");
	    breeds.add("Beagle");
	    breeds.add("Boxer");
	    breeds.add("British Bulldog");
	    breeds.add("Other...");
	    return breeds;
	}
}
