package sen3004.hw.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import sen3004.hw.model.Dog;
import sen3004.hw.service.HwInterface;

@Repository
public class HwRepository implements HwInterface {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public List<Dog> findAll() {
		return entityManager.createQuery("from Dog",Dog.class).getResultList();
	}

	@Override
	public void create(Dog dog) {
		entityManager.persist(dog);
	}

	@Override
	public Dog findById(long id) {
		return entityManager.find(Dog.class,id);
	}

	@Override
	public void update(Dog dog) {
		entityManager.merge(dog);
	}
	
	
	
	

}
