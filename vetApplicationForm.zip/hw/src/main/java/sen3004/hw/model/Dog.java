package sen3004.hw.model;

import java.time.LocalDate;

import javax.persistence.*;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="dog")
public class Dog {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Size(min=3,max=20)
	@Column(name = "ofn")
	private String ownerfName;
	
	@Size(min=3,max=20)
	@Column(name = "oln")
	private String ownerlName;
	
	@NotEmpty
	@Column(name = "breed")
	private String breeds;
	
	@NotEmpty
	@Column(name = "gender")
	private String gender;
		
	@Min(3)
	@Max(70)
	@Column(name = "weight")
	private int weight;
	
	@Min(0)
	@Max(20)
	@Column(name = "age")
	private int age;
	
	@NotNull
	@Future
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	@Column(name = "appointmentdate")
	private LocalDate dateOfAppointment;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getBreeds() {
		return breeds;
	}
	public void setBreeds(String breeds) {
		this.breeds = breeds;
	}
	
	public String getOwnerfName() {
		return ownerfName;
	}
	public void setOwnerfName(String ownerfName) {
		this.ownerfName = ownerfName;
	}
	public String getOwnerlName() {
		return ownerlName;
	}
	public void setOwnerlName(String ownerlName) {
		this.ownerlName = ownerlName;
	}
	public LocalDate getDateOfAppointment() {
		return dateOfAppointment;
	}
	public void setDateOfAppointment(LocalDate dateOfAppointment) {
		this.dateOfAppointment = dateOfAppointment;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}
