package sen3004.hw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HwApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(HwApplication.class, args);

	}

}
